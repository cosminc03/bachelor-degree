$(function () {
    if ($('#general-alert').length) {
        setTimeout(function () {
            $('#general-alert').fadeOut('slow');
        }, 2000);
    }
});
