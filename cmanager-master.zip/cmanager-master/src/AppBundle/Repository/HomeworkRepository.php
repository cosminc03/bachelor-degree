<?php

namespace AppBundle\Repository;

use Doctrine\ORM\EntityRepository;

class HomeworkRepository extends EntityRepository
{
}
