<?php

namespace AppBundle\Repository;

class FileRepository extends BaseRepository
{
}
