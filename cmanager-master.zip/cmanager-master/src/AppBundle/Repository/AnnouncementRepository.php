<?php

namespace AppBundle\Repository;

class AnnouncementRepository extends BaseRepository
{
}
