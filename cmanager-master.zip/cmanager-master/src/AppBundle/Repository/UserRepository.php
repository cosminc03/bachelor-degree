<?php

namespace AppBundle\Repository;

class UserRepository extends BaseRepository
{
}
